
export default function Member() {
  return <>
    <div className="text-center mt-5">
      <h2 className="py-2">اختر العمليه المناسبة</h2>
    </div>
  </>
}
